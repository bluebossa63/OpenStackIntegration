package com.woorea.openstack.swift.deserializer;

import java.io.IOException;

import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.DeserializationContext;
import org.codehaus.jackson.map.JsonDeserializer;

import com.woorea.openstack.swift.model.Objects;

public class ObjectsDeserializer extends JsonDeserializer<Objects> {

	@Override
	public Objects deserialize(JsonParser jp, DeserializationContext ctxt)
			throws IOException, JsonProcessingException {
		com.woorea.openstack.swift.model.Object[] containersArray = jp.readValueAs(com.woorea.openstack.swift.model.Object[].class);
		return new Objects(containersArray);
	}

}
