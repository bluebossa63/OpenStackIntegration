package com.woorea.openstack.swift.deserializer;

import java.io.IOException;

import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.DeserializationContext;
import org.codehaus.jackson.map.JsonDeserializer;

import com.woorea.openstack.swift.model.Container;
import com.woorea.openstack.swift.model.Containers;

public class ContainersDeserializer extends JsonDeserializer<Containers> {

	@Override
	public Containers deserialize(JsonParser jp, DeserializationContext ctxt)
			throws IOException, JsonProcessingException {
		Container[] containersArray = jp.readValueAs(Container[].class);
		return new Containers(containersArray);
	}

}
